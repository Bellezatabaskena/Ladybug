﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;


namespace PromediosEdad
{
   
    class Persona
    {
        private int edad1,edad2,edad3;
        private int dia, tarde, noche;
        private int sumaEdad1, sumaEdad2, sumaEdad3;
        private int f, g, h;
        public void inicializar()
        {
            Console.WriteLine();
            Console.WriteLine("*********************************************************");
            Console.WriteLine("********** Bienvenido a los Promedios de Edades *********");
            Console.WriteLine("**************                                ***********");
            Console.WriteLine("*****************     PERLA MENDO LOPEZ    **************");
            Console.WriteLine("*********************************************************");
            Console.WriteLine();
            for (f = 1; f <= 10; f++)
            {
                Console.WriteLine(" Por favor, ingrese la edad del estudiante turno de Dia: ");
                edad1 = int.Parse(Console.ReadLine());
                sumaEdad1 = sumaEdad1 + edad1;
            }
            Console.WriteLine();
            Console.WriteLine("*********************************************************");
            Console.WriteLine();
            for (g = 1; g <= 10; g++)
            {
                Console.WriteLine(" Por favor,ingrese la edad del estudiante turno de Tarde: ");
                edad2 = int.Parse(Console.ReadLine());
                sumaEdad2 = sumaEdad2 + edad2;
            }
            Console.WriteLine();
            Console.WriteLine("*********************************************************");
            Console.WriteLine();
            for (h = 1; h <= 10; h++)
            {
                Console.WriteLine(" Por favor, ingrese la edad del estuidante turno de Noche: ");
                edad3 = int.Parse(Console.ReadLine());
                sumaEdad3 = sumaEdad3 + edad3;
            }
        }

        public void SumaPromedios()
        {  
            dia = sumaEdad1 / 10;
            tarde = sumaEdad2 / 10;
            noche = sumaEdad3 / 10;

            Console.WriteLine();
            Console.WriteLine("*********************************************************");
            Console.WriteLine("******************** SUMA DE PROMEDIOS ******************");
            Console.WriteLine("*********************************************************");
            Console.WriteLine();
            Console.WriteLine(" Promedio turno de Dia: ");
            Console.WriteLine(dia);
            Console.WriteLine(" Promedio turno de Tarde: ");
            Console.WriteLine(tarde);
            Console.WriteLine(" Promedio turno de Noche: ");
            Console.WriteLine(noche);
        }

        public void PromedioMenor()
        {   
            Console.WriteLine("*********************************************************");
            Console.WriteLine("*********************PROMEDIO MENOR**********************");
            Console.WriteLine("*********************************************************");
            Console.WriteLine();
            if (dia > tarde)
            {
                if (tarde > noche)
                {
                    Console.WriteLine("El turno de Noche tiene menor promedio");
                }
                else
                    Console.WriteLine("El turno de Tarde tiene menor promedio");
            }
            else if (dia < tarde)
            {
                if (dia < noche)
                {
                    Console.WriteLine("El turno de Dia tiene menor promedio");
                }
                else
                    Console.WriteLine("El turno de Noche tiene menor promedio");
            }
            Console.WriteLine();
            Console.WriteLine("*********************************************************");
            Console.WriteLine("*************** Fin del programa. Gracias ***************");
            Console.WriteLine("*********************************************************");
        }
        static void Main(string[] args)
        {
           Persona per1= new Persona();
            per1.inicializar();
            per1.SumaPromedios();
            per1.PromedioMenor(); 
            
            Console.ReadKey();
        }
    }
}
